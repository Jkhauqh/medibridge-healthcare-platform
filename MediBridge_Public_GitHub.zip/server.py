#!/usr/bin/env python3
"""Local MediBridge server with a small SQLite persistence API."""

from __future__ import annotations

import json
import math
import os
import platform
import re
import shutil
import sqlite3
import ssl
import subprocess
import sys
import threading
import time
import uuid
from contextlib import closing
from datetime import datetime, timezone
from html import unescape
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote, unquote, urlencode, urlparse
from urllib.request import Request, urlopen


APP_DIR = Path(__file__).resolve().parent


def load_local_env() -> None:
    """Load optional local API configuration without replacing shell variables."""
    env_path = APP_DIR / ".env"
    if not env_path.is_file():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        name, value = name.strip(), value.strip()
        if value[:1] == value[-1:] and value[:1] in {"'", '"'}:
            value = value[1:-1]
        if name and name not in os.environ:
            os.environ[name] = value


load_local_env()
DATA_DIR = APP_DIR / "data"
DATABASE_PATH = DATA_DIR / "medibridge.sqlite3"
SCHEMA_PATH = APP_DIR / "schema.sql"
HOST = "127.0.0.1"
PORT = 8765
MAX_BODY_BYTES = 1_000_000
ALLOWED_ESTIMATE_MODES = {"hospital", "overall"}
ALLOWED_ENQUIRY_STATUSES = {"Received", "Under review", "Quotation ready", "Closed"}
NOMINATIM_URL = os.environ.get("MEDIBRIDGE_NOMINATIM_URL", "https://nominatim.openstreetmap.org").rstrip("/")
PHOTON_URL = os.environ.get("MEDIBRIDGE_PHOTON_URL", "https://photon.komoot.io/api/")
OVERPASS_URL = os.environ.get("MEDIBRIDGE_OVERPASS_URL", "https://overpass-api.de/api/interpreter")
OVERPASS_FALLBACK_URL = os.environ.get(
    "MEDIBRIDGE_OVERPASS_FALLBACK_URL", "https://overpass.private.coffee/api/interpreter"
)
OVERPASS_TERTIARY_URL = os.environ.get(
    "MEDIBRIDGE_OVERPASS_TERTIARY_URL", "https://maps.mail.ru/osm/tools/overpass/api/interpreter"
)
MAPPLS_ACCESS_TOKEN = os.environ.get("MEDIBRIDGE_MAPPLS_ACCESS_TOKEN", "").strip()
MAPPLS_GEOCODE_URL = "https://search.mappls.com/search/address/geocode?"
MAPPLS_NEARBY_URL = "https://search.mappls.com/search/places/nearby/json?"
GEOAPIFY_API_KEY = os.environ.get("MEDIBRIDGE_GEOAPIFY_API_KEY", "").strip()
GEOAPIFY_GEOCODE_URL = "https://api.geoapify.com/v1/geocode/search?"
GEOAPIFY_PLACES_URL = "https://api.geoapify.com/v2/places?"
LIVE_DATA_CACHE: dict[str, tuple[float, object]] = {}
LIVE_DATA_CACHE_LOCK = threading.Lock()
NOMINATIM_REQUEST_LOCK = threading.Lock()
LAST_NOMINATIM_REQUEST = 0.0
COMMONS_REQUEST_LOCK = threading.Lock()
LAST_COMMONS_REQUEST = 0.0


def fetch_json(url: str, *, method: str = "GET", payload: dict[str, object] | None = None,
               body: bytes | None = None, headers: dict[str, str] | None = None,
               timeout: int = 20) -> dict[str, object]:
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
    request_headers = {"User-Agent": "MediBridgeAcademicPrototype/1.0", "Accept": "application/json"}
    request_headers.update(headers or {})
    request = Request(url, data=body, method=method, headers=request_headers)
    try:
        with urlopen(request, timeout=timeout) as response:
            response_body = response.read()
    except URLError as error:
        # On macOS, Python's OpenSSL CA bundle can disagree with certificates
        # trusted by the system Keychain (for example, an institution's proxy
        # CA). Retry only certificate-verification failures with Apple's curl
        # SecureTransport backend. TLS verification remains enabled.
        reason = getattr(error, "reason", None)
        certificate_error = isinstance(reason, ssl.SSLCertVerificationError) or (
            "CERTIFICATE_VERIFY_FAILED" in str(error).upper()
            or "SELF-SIGNED CERTIFICATE IN CERTIFICATE CHAIN" in str(error).upper()
        )
        curl = shutil.which("curl") if sys.platform == "darwin" and certificate_error else None
        if not curl:
            raise
        response_body = fetch_with_macos_trust(
            curl, url, method=method, body=body, headers=request_headers,
            timeout=timeout, original_error=error,
        )
    if not response_body.strip():
        return {}
    result = json.loads(response_body.decode("utf-8"))
    if isinstance(result, list):
        return {"data": result}
    if not isinstance(result, dict):
        raise ValueError("The live data provider returned an unexpected response.")
    return result


def fetch_image(url: str, *, timeout: int = 12) -> bytes:
    """Fetch a PNG tile, preserving TLS verification and the macOS trust fallback."""
    headers = {"User-Agent": "MediBridge/1.0", "Accept": "image/png"}
    request = Request(url, headers=headers)
    try:
        with urlopen(request, timeout=timeout) as response:
            content_type = response.headers.get_content_type()
            body = response.read()
    except URLError as error:
        reason = getattr(error, "reason", None)
        certificate_error = isinstance(reason, ssl.SSLCertVerificationError) or (
            "CERTIFICATE_VERIFY_FAILED" in str(error).upper()
            or "SELF-SIGNED CERTIFICATE IN CERTIFICATE CHAIN" in str(error).upper()
        )
        curl = shutil.which("curl") if sys.platform == "darwin" and certificate_error else None
        if not curl:
            raise
        body = fetch_with_macos_trust(
            curl, url, method="GET", body=None, headers=headers, timeout=timeout,
            original_error=error,
        )
        content_type = "image/png"
    if content_type != "image/png" or not body.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("The map provider did not return a PNG tile.")
    return body


def fetch_with_macos_trust(curl: str, url: str, *, method: str, body: bytes | None,
                           headers: dict[str, str], timeout: int,
                           original_error: BaseException) -> bytes:
    """Retry a certificate failure through macOS SecureTransport/Keychain."""
    status_marker = b"\n__MEDIBRIDGE_HTTP_STATUS__"
    command = [curl, "--silent", "--show-error", "--location", "--max-time", str(timeout),
               "--connect-timeout", str(min(timeout, 10)), "--request", method]
    for name, value in headers.items():
        command.extend(("--header", f"{name}: {value}"))
    if body is not None:
        command.extend(("--data-binary", "@-"))
    command.extend(("--write-out", "\\n__MEDIBRIDGE_HTTP_STATUS__%{http_code}", url))
    try:
        process = subprocess.run(command, input=body, capture_output=True,
                                 timeout=timeout + 2, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise URLError(
            f"Python TLS verification failed ({original_error}); macOS Keychain retry failed ({error})."
        ) from error
    response, marker, status_text = process.stdout.rpartition(status_marker)
    if not marker:
        detail = process.stderr.decode("utf-8", errors="replace").strip() or "no HTTP response"
        raise URLError(
            f"Python TLS verification failed ({original_error}); macOS Keychain retry failed ({detail}). "
            "TLS verification stayed enabled."
        ) from original_error
    try:
        status = int(status_text.strip())
    except ValueError as error:
        raise URLError("macOS Keychain retry returned an invalid HTTP status.") from error
    if status >= 400:
        raise HTTPError(url, status, "HTTP request failed through macOS Keychain", None, BytesIO(response))
    if process.returncode != 0:
        detail = process.stderr.decode("utf-8", errors="replace").strip() or "curl failed"
        raise URLError(f"macOS Keychain retry failed: {detail}")
    return response


def live_provider_error(error: BaseException) -> str:
    """Give useful next steps for TLS failures reaching public map services."""
    message = str(error)
    if "handshake failure" in message.casefold() or "sslv3_alert_handshake_failure" in message.casefold():
        return (f"{message} This server is using Python {platform.python_version()} with {ssl.OPENSSL_VERSION}. "
                "Stop MediBridge and restart it with Start_MediBridge.command, which prefers a modern OpenSSL Python runtime.")
    if "certificate_verify_failed" in message.casefold() or "self-signed certificate" in message.casefold():
        return (f"{message} The app keeps TLS certificate checks enabled. This usually means the current network "
                "is presenting an untrusted HTTPS inspection certificate; try another network, or ask the network "
                "administrator to trust its official root certificate in macOS Keychain.")
    return message


def fetch_commons_json(url: str) -> dict[str, object]:
    global LAST_COMMONS_REQUEST
    with COMMONS_REQUEST_LOCK:
        wait = 1.05 - (time.monotonic() - LAST_COMMONS_REQUEST)
        if wait > 0:
            time.sleep(wait)
        LAST_COMMONS_REQUEST = time.monotonic()
        return fetch_json(url, headers={
            "User-Agent": "MediBridge/1.0",
            "Accept-Language": "en",
        })


def cache_value(key: str, loader, ttl_seconds: int = 21600):
    now = time.time()
    with LIVE_DATA_CACHE_LOCK:
        cached = LIVE_DATA_CACHE.get(key)
        if cached and now - cached[0] < ttl_seconds:
            return cached[1]
    result = loader()
    with LIVE_DATA_CACHE_LOCK:
        if len(LIVE_DATA_CACHE) > 500:
            for old_key, (saved_at, _) in list(LIVE_DATA_CACHE.items()):
                if now - saved_at > ttl_seconds:
                    LIVE_DATA_CACHE.pop(old_key, None)
        LIVE_DATA_CACHE[key] = (now, result)
    return result


def clean_metadata(value: object) -> str:
    return unescape(re.sub(r"<[^>]*>", " ", str(value or ""))).replace("\xa0", " ").strip()


def commons_match_score(title: str, description: str, name: str, city: str, place_type: str) -> float | None:
    ignored = {
        "hospital", "hospitals", "hotel", "hotels", "medical", "center", "centre", "clinic", "clinics",
        "health", "healthcare", "care", "institute", "institution", "university", "college", "trust",
        "speciality", "specialty", "super", "the", "and", "of", "in", "india",
    }
    name_tokens = [token for token in re.findall(r"[a-z0-9]+", name.casefold()) if token not in ignored and len(token) > 2]
    city_tokens = {token for token in re.findall(r"[a-z0-9]+", city.casefold()) if token not in ignored and len(token) > 2}
    specific_name_tokens = [token for token in name_tokens if token not in city_tokens]
    # A city or facility-type word alone is not enough to identify a photo.
    if not specific_name_tokens:
        return None
    entity_context = (
        {"hospital", "hospitals", "clinic", "clinics", "medical", "health", "healthcare", "institute", "centre", "center", "building", "campus", "ward"}
        if place_type == "hospital" else
        {"hotel", "hotels", "guest", "house", "hostel", "motel", "resort", "lodging", "inn", "suites", "accommodation", "palace", "residency", "residence", "property", "building", "facade", "front"}
    )
    title_tokens = set(re.findall(r"[a-z0-9]+", title.casefold()))
    description_tokens = set(re.findall(r"[a-z0-9]+", description.casefold()))
    matched_tokens = [token for token in specific_name_tokens if token in title_tokens or token in description_tokens]
    title_match_count = sum(token in title_tokens for token in specific_name_tokens)
    required_matches = 1 if len(specific_name_tokens) == 1 else max(2, math.ceil(len(specific_name_tokens) * 0.66))
    if title_match_count == 0 or len(matched_tokens) < required_matches or not (title_tokens & entity_context):
        return None
    return len(matched_tokens) / len(specific_name_tokens) + (0.15 if title_match_count else 0)


def commons_photo(reference: str, place_name: str = "", city: str = "", place_type: str = "hospital") -> dict[str, object] | None:
    reference = text_value(reference, 300)
    if not reference:
        return None
    place_type = place_type if place_type in {"hospital", "hotel"} else "hospital"
    key = "commons:" + ":".join((reference, place_type, place_name, city)).casefold()

    def load_photo():
        commons_api = "https://commons.wikimedia.org/w/api.php"
        if reference.casefold().startswith("category:"):
            category_query = urlencode({
                "action": "query", "format": "json", "list": "categorymembers",
                "cmtitle": reference, "cmtype": "file", "cmlimit": "20",
            })
            category_data = fetch_commons_json(commons_api + "?" + category_query)
            members = category_data.get("query", {}).get("categorymembers", [])
            titles = "|".join(item.get("title", "") for item in members if isinstance(item, dict))
            if not titles:
                return None
        else:
            titles = reference if reference.casefold().startswith("file:") else "File:" + reference
        image_query = urlencode({
            "action": "query", "format": "json", "prop": "imageinfo",
            "iiprop": "url|extmetadata", "iiurlwidth": "720", "titles": titles,
        })
        data = fetch_commons_json(commons_api + "?" + image_query)
        pages = data.get("query", {}).get("pages", {})
        if not isinstance(pages, dict):
            return None
        candidates = []
        for page in pages.values():
            info = page.get("imageinfo", [{}])[0] if isinstance(page, dict) else {}
            metadata = info.get("extmetadata", {}) if isinstance(info, dict) else {}
            license_entry = metadata.get("LicenseShortName", {})
            license_name = clean_metadata(license_entry.get("value") if isinstance(license_entry, dict) else "")
            image_url = info.get("thumburl") or info.get("url") if isinstance(info, dict) else ""
            if not image_url or not license_name:
                continue
            title = str(page.get("title", ""))
            description_entry = metadata.get("ImageDescription", {})
            description = clean_metadata(description_entry.get("value") if isinstance(description_entry, dict) else "")
            score = commons_match_score(title, description, place_name, city, place_type) if place_name else 0.0
            if score is None:
                continue
            file_url = "https://commons.wikimedia.org/wiki/" + quote(title.replace(" ", "_"), safe="/:()")
            artist_entry = metadata.get("Artist", {})
            credit_entry = metadata.get("Credit", {})
            author = clean_metadata(artist_entry.get("value") if isinstance(artist_entry, dict) else "")
            author = author or clean_metadata(credit_entry.get("value") if isinstance(credit_entry, dict) else "")
            credit = f"{author} · {license_name}" if author else license_name
            candidates.append((score, {
                "url": image_url,
                "sourceUrl": file_url,
                "license": license_name,
                "authorAttributions": [{"displayName": credit, "uri": file_url}],
            }))
        return max(candidates, key=lambda candidate: candidate[0])[1] if candidates else None

    try:
        return cache_value(key, load_photo)
    except (HTTPError, URLError, TimeoutError, ValueError, TypeError):
        return None


def commons_search_photo(name: str, city: str, place_type: str) -> dict[str, object] | None:
    """Find a name-matching Commons image and retain its license/credit metadata."""
    name = text_value(name, 180)
    city = text_value(city, 100)
    place_type = place_type if place_type in {"hospital", "hotel"} else "hospital"
    if not name:
        return None
    cache_key = "commons-search:" + ":".join((place_type, name, city)).casefold()

    def load_photo():
        commons_api = "https://commons.wikimedia.org/w/api.php"
        search_terms = " ".join(part for part in (name, city, place_type, "India") if part)
        params = urlencode({
            "action": "query", "format": "json", "generator": "search",
            "gsrsearch": search_terms, "gsrnamespace": "6", "gsrlimit": "8",
            "prop": "imageinfo", "iiprop": "url|extmetadata", "iiurlwidth": "720",
        })
        response = fetch_commons_json(commons_api + "?" + params)
        pages = response.get("query", {}).get("pages", {})
        if not isinstance(pages, dict):
            return None
        candidates = []
        for page in pages.values():
            if not isinstance(page, dict):
                continue
            info = page.get("imageinfo", [{}])[0]
            if not isinstance(info, dict):
                continue
            metadata = info.get("extmetadata", {})
            if not isinstance(metadata, dict):
                continue
            license_entry = metadata.get("LicenseShortName", {})
            license_name = clean_metadata(license_entry.get("value") if isinstance(license_entry, dict) else "")
            image_url = info.get("thumburl") or info.get("url")
            if not image_url or not license_name:
                continue
            title = str(page.get("title", ""))
            description_entry = metadata.get("ImageDescription", {})
            description = clean_metadata(description_entry.get("value") if isinstance(description_entry, dict) else "")
            score = commons_match_score(title, description, name, city, place_type)
            if score is None:
                continue
            file_url = "https://commons.wikimedia.org/wiki/" + quote(title.replace(" ", "_"), safe="/:()")
            artist_entry = metadata.get("Artist", {})
            credit_entry = metadata.get("Credit", {})
            author = clean_metadata(artist_entry.get("value") if isinstance(artist_entry, dict) else "")
            author = author or clean_metadata(credit_entry.get("value") if isinstance(credit_entry, dict) else "")
            credit = f"{author} · {license_name}" if author else license_name
            candidates.append((score, {
                "url": image_url,
                "sourceUrl": file_url,
                "license": license_name,
                "authorAttributions": [{"displayName": credit, "uri": file_url}],
            }))
        return max(candidates, key=lambda candidate: candidate[0])[1] if candidates else None

    try:
        return cache_value(cache_key, load_photo, ttl_seconds=30 * 86400)
    except (HTTPError, URLError, TimeoutError, ValueError, TypeError):
        return None


def osm_place_from_nominatim(item: dict[str, object]) -> dict[str, object]:
    extras = item.get("extratags") if isinstance(item.get("extratags"), dict) else {}
    names = item.get("namedetails") if isinstance(item.get("namedetails"), dict) else {}
    address = item.get("address") if isinstance(item.get("address"), dict) else {}
    name = str(names.get("name") or item.get("name") or item.get("display_name", "OpenStreetMap place").split(",")[0])
    osm_type = str(item.get("osm_type", ""))
    osm_id = str(item.get("osm_id", ""))
    osm_url = f"https://www.openstreetmap.org/{osm_type}/{osm_id}" if osm_type and osm_id else "https://www.openstreetmap.org/"
    commons = str(extras.get("wikimedia_commons", ""))
    city = str(address.get("city") or address.get("town") or address.get("municipality") or "")
    photo = commons_photo(commons, name, city, "hospital") if commons else None
    area = ", ".join(str(address.get(key)) for key in ("road", "suburb", "city", "state", "postcode") if address.get(key))
    return {
        "id": f"{osm_type}:{osm_id}",
        "displayName": {"text": name},
        "formattedAddress": str(item.get("display_name") or area),
        "location": {"latitude": number_value(item.get("lat"), float("nan")), "longitude": number_value(item.get("lon"), float("nan"))},
        "distanceMeters": 0,
        "rating": None,
        "userRatingCount": 0,
        "photos": [photo] if photo else [],
        "websiteUri": extras.get("website") or extras.get("contact:website") or "",
        "nationalPhoneNumber": extras.get("phone") or extras.get("contact:phone") or "",
        "osmUrl": osm_url,
        "source": "OpenStreetMap",
        "mapClass": str(item.get("category", "")) + "/" + str(item.get("type", "")),
    }


def osm_hospital_search(query: str) -> list[dict[str, object]]:
    cache_key = "nominatim:" + re.sub(r"\s+", " ", query).strip().casefold()

    def search():
        global LAST_NOMINATIM_REQUEST
        params = urlencode({
            "q": query, "format": "jsonv2", "limit": "5", "countrycodes": "in",
            "addressdetails": "1", "extratags": "1", "namedetails": "1",
        })
        with NOMINATIM_REQUEST_LOCK:
            wait = 1.05 - (time.monotonic() - LAST_NOMINATIM_REQUEST)
            if wait > 0:
                time.sleep(wait)
            LAST_NOMINATIM_REQUEST = time.monotonic()
            result = fetch_json(f"{NOMINATIM_URL}/search?{params}", headers={"Accept-Language": "en"})
        items = result.get("data", [])
        return [osm_place_from_nominatim(item) for item in items if isinstance(item, dict)]

    return cache_value(cache_key, search, ttl_seconds=86400)


def photon_city_location(city: str, state: str) -> dict[str, object] | None:
    """Use Photon as a secondary OSM geocoder when Nominatim has no usable city result."""
    cache_key = "photon-city:" + re.sub(r"\s+", " ", f"{city},{state}").strip().casefold()

    def search():
        params = urlencode({"q": ", ".join(part for part in (city, state, "India") if part),
                           "countrycode": "in", "limit": "8", "lang": "en"})
        result = fetch_json(f"{PHOTON_URL}?{params}", timeout=12)
        target_city = re.sub(r"[^a-z0-9]+", " ", city.casefold()).strip()
        target_state = re.sub(r"[^a-z0-9]+", " ", state.casefold()).strip()
        candidates: list[tuple[int, dict[str, object]]] = []
        for feature in result.get("features", []):
            if not isinstance(feature, dict):
                continue
            properties = feature.get("properties") if isinstance(feature.get("properties"), dict) else {}
            geometry = feature.get("geometry") if isinstance(feature.get("geometry"), dict) else {}
            coordinates = geometry.get("coordinates") if isinstance(geometry.get("coordinates"), list) else []
            if len(coordinates) < 2 or str(properties.get("countrycode", "")).casefold() not in {"in", ""}:
                continue
            result_state = re.sub(r"[^a-z0-9]+", " ", str(properties.get("state", "")).casefold()).strip()
            if target_state and result_state and target_state != result_state:
                continue
            place_names = [properties.get(key) for key in ("city", "town", "village", "name")]
            normalized_names = [re.sub(r"[^a-z0-9]+", " ", str(value).casefold()).strip()
                                for value in place_names if value]
            if target_city not in normalized_names:
                continue
            try:
                longitude, latitude = float(coordinates[0]), float(coordinates[1])
            except (TypeError, ValueError):
                continue
            if not (math.isfinite(latitude) and math.isfinite(longitude)
                    and -90 <= latitude <= 90 and -180 <= longitude <= 180):
                continue
            score = 2 if result_state == target_state else 1
            label = str(properties.get("name") or city)
            place = {"displayName": {"text": ", ".join(part for part in (label, state, "India") if part)},
                     "location": {"latitude": latitude, "longitude": longitude}}
            candidates.append((score, place))
        return max(candidates, key=lambda item: item[0])[1] if candidates else None

    return cache_value(cache_key, search, ttl_seconds=86400)


def geo_distance_meters(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    radius = 6371000
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    d_phi, d_lam = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    value = math.sin(d_phi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(d_lam / 2) ** 2
    return radius * 2 * math.atan2(math.sqrt(value), math.sqrt(1 - value))


def mappls_geocode(query: str) -> dict[str, object]:
    """Resolve a hospital or city to a Mappls eLoc for nearby-place searches."""
    if not MAPPLS_ACCESS_TOKEN:
        raise URLError(
            "Mappls is not configured yet. Add MEDIBRIDGE_MAPPLS_ACCESS_TOKEN to the local .env file and restart the server."
        )
    params = urlencode({"address": query, "access_token": MAPPLS_ACCESS_TOKEN})
    result = fetch_json(f"{MAPPLS_GEOCODE_URL}{params}", timeout=12)
    candidates = result.get("copResults", [])
    if isinstance(candidates, dict):
        candidates = [candidates]
    if not isinstance(candidates, list) or not candidates:
        raise ValueError(f"Mappls could not locate {query}.")
    candidates = [item for item in candidates if isinstance(item, dict)]
    if not candidates:
        raise ValueError(f"Mappls could not locate {query}.")
    return max(candidates, key=lambda item: number_value(item.get("confidenceScore"), 0))


def mappls_nearby_hotels(reference: str, radius: int) -> list[dict[str, object]]:
    """Find nearby lodging through Mappls Nearby API using coordinates or an eLoc."""
    if not MAPPLS_ACCESS_TOKEN:
        raise URLError(
            "Mappls is not configured yet. Add MEDIBRIDGE_MAPPLS_ACCESS_TOKEN to the local .env file and restart the server."
        )
    params = urlencode({
        "keywords": "hotel;guest house;resort;hostel",
        "refLocation": reference,
        "radius": radius,
        "region": "IND",
        "sortBy": "dist:asc",
        "access_token": MAPPLS_ACCESS_TOKEN,
    })
    result = fetch_json(f"{MAPPLS_NEARBY_URL}{params}", timeout=15)
    places = result.get("suggestedLocations", [])
    if not isinstance(places, list):
        return []
    hotels = []
    for item in places:
        if not isinstance(item, dict):
            continue
        name = text_value(item.get("placeName"), 180)
        if not name:
            continue
        eloc = text_value(item.get("eLoc"), 12)
        distance = number_value(item.get("distance"), 0)
        hotels.append({
            "id": f"mappls:{eloc or uuid.uuid5(uuid.NAMESPACE_URL, name + str(item.get('placeAddress', '')))}",
            "displayName": {"text": name},
            "formattedAddress": text_value(item.get("placeAddress"), 300),
            "location": {}, "distanceMeters": max(0, distance),
            "rating": None, "userRatingCount": 0, "hotelClass": None,
            "lodgingType": "Hotel or nearby stay", "photos": [],
            "websiteUri": "", "nationalPhoneNumber": text_value(item.get("mobileNo") or item.get("landlineNo"), 40),
            "mapUrl": f"https://mappls.com/{quote(eloc)}" if eloc else "https://www.mappls.com/",
            "source": "Mappls",
        })
    return sorted(hotels, key=lambda hotel: hotel["distanceMeters"])[:10]


def mappls_city_hotels(city: str, state: str, radius: int) -> tuple[list[dict[str, object]], str]:
    query = ", ".join(part for part in (city, state, "India") if part)
    if not city.strip():
        return [], ""
    place = mappls_geocode(query)
    reference = text_value(place.get("eLoc") or place.get("eloc"), 12)
    if not reference:
        raise ValueError(f"Mappls found {query}, but its result did not include a nearby-search location code.")
    listings = mappls_nearby_hotels(reference, radius)
    origin = text_value(place.get("formattedAddress") or place.get("city") or city, 240)
    return listings, origin


def mappls_hospital_hotels(name: str, city: str, state: str, radius: int) -> tuple[list[dict[str, object]], str, str, str]:
    """Try the selected hospital, then fall back to the city's Mappls location."""
    name = text_value(name, 180)
    city = text_value(city, 100)
    state = text_value(state, 100)
    if not name or not city:
        raise ValueError("Choose a hospital and city to find nearby stays.")
    hospital_query = ", ".join(part for part in (name, city, state, "India") if part)
    notice = ""
    try:
        place = mappls_geocode(hospital_query)
        confidence = number_value(place.get("confidenceScore"), 0)
        identity = " ".join(str(place.get(key, "")) for key in ("poi", "houseName", "formattedAddress"))
        name_tokens = [token for token in re.findall(r"[a-z0-9]+", name.casefold()) if len(token) > 2]
        matched = bool(name_tokens) and sum(token in identity.casefold() for token in name_tokens) / len(name_tokens) >= 0.5
        reference = text_value(place.get("eLoc") or place.get("eloc"), 12)
        if reference and (matched or confidence >= 0.8):
            listings = mappls_nearby_hotels(reference, radius)
            if listings:
                return listings, text_value(place.get("formattedAddress") or name, 240), "hospital", ""
            notice = "No Mappls stays were returned for the hospital location; showing city-area results."
        else:
            notice = "No confident hospital location match; showing city-area results."
    except (HTTPError, URLError, TimeoutError, ValueError) as error:
        # A failed hospital-specific match should not prevent a useful city search.
        notice = f"Hospital location lookup unavailable ({error}); showing city-area results."
    listings, origin = mappls_city_hotels(city, state, radius)
    return listings, origin or city, "city-centre", notice


def geoapify_geocode(query: str) -> list[dict[str, object]]:
    """Resolve an Indian hospital or city using Geoapify's geocoder."""
    if not GEOAPIFY_API_KEY:
        raise URLError("Geoapify is not configured. Add MEDIBRIDGE_GEOAPIFY_API_KEY to .env and restart MediBridge.")
    normalized = re.sub(r"\s+", " ", query).strip()
    cache_key = "geoapify-geocode:" + normalized.casefold()

    def search():
        params = urlencode({
            "text": normalized,
            "filter": "countrycode:in",
            "format": "json",
            "limit": "8",
            "apiKey": GEOAPIFY_API_KEY,
        })
        result = fetch_json(f"{GEOAPIFY_GEOCODE_URL}{params}", timeout=15)
        items = result.get("results", [])
        return [item for item in items if isinstance(item, dict)] if isinstance(items, list) else []

    return cache_value(cache_key, search, ttl_seconds=86400)


def geoapify_coordinates(item: dict[str, object]) -> tuple[float, float] | None:
    latitude = number_value(item.get("lat"), float("nan"))
    longitude = number_value(item.get("lon"), float("nan"))
    if not (math.isfinite(latitude) and math.isfinite(longitude)
            and -90 <= latitude <= 90 and -180 <= longitude <= 180):
        return None
    return latitude, longitude


def normalized_place_text(value: object) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").casefold()).strip()


def geoapify_city_location(city: str, state: str) -> dict[str, object] | None:
    city = text_value(city, 100)
    state = text_value(state, 100)
    if not city:
        return None
    query = ", ".join(part for part in (city, state, "India") if part)
    target_city = normalized_place_text(city)
    candidates: list[tuple[float, dict[str, object]]] = []
    for item in geoapify_geocode(query):
        coords = geoapify_coordinates(item)
        if not coords or str(item.get("country_code", "in")).casefold() != "in":
            continue
        city_name = normalized_place_text(item.get("city") or item.get("name"))
        formatted = normalized_place_text(item.get("formatted"))
        if city_name != target_city and not re.search(rf"\b{re.escape(target_city)}\b", formatted):
            continue
        rank = item.get("rank") if isinstance(item.get("rank"), dict) else {}
        confidence = number_value(rank.get("confidence"), 0)
        exact_city = 2 if city_name == target_city else 1
        result_type = 1 if item.get("result_type") == "city" else 0
        candidates.append((exact_city + result_type + confidence, item))
    if not candidates:
        return None
    best = max(candidates, key=lambda candidate: candidate[0])[1]
    latitude, longitude = geoapify_coordinates(best) or (0, 0)
    return {
        "displayName": {"text": text_value(best.get("formatted") or best.get("name") or city, 240)},
        "location": {"latitude": latitude, "longitude": longitude},
    }


def geoapify_hospital_location(name: str, city: str, state: str, address: str = "") -> dict[str, object] | None:
    name = text_value(name, 180)
    city = text_value(city, 100)
    state = text_value(state, 100)
    address = text_value(address, 180)
    query = ", ".join(part for part in (name, address, city, state, "India") if part)
    ignored = {"hospital", "hospitals", "medical", "clinic", "clinics", "center", "centre", "the", "and", "india"}
    tokens = [token for token in re.findall(r"[a-z0-9]+", name.casefold()) if len(token) > 2 and token not in ignored]
    target_city = normalized_place_text(city)
    candidates: list[tuple[float, dict[str, object]]] = []
    for item in geoapify_geocode(query):
        coords = geoapify_coordinates(item)
        if not coords or str(item.get("country_code", "in")).casefold() != "in":
            continue
        city_name = normalized_place_text(item.get("city"))
        formatted = normalized_place_text(item.get("formatted"))
        city_match = city_name == target_city or bool(re.search(rf"\b{re.escape(target_city)}\b", formatted))
        if not city_match:
            continue
        identity = normalized_place_text(" ".join(str(item.get(key, "")) for key in ("name", "address_line1", "formatted")))
        overlap = sum(token in identity.split() for token in tokens) / max(1, len(tokens))
        if overlap < 0.4:
            continue
        rank = item.get("rank") if isinstance(item.get("rank"), dict) else {}
        confidence = number_value(rank.get("confidence"), 0)
        candidates.append((overlap * 2 + confidence, item))
    if not candidates:
        return None
    best = max(candidates, key=lambda candidate: candidate[0])[1]
    latitude, longitude = geoapify_coordinates(best) or (0, 0)
    return {
        "displayName": {"text": text_value(best.get("formatted") or name, 240)},
        "location": {"latitude": latitude, "longitude": longitude},
    }


def geoapify_nearby_hotels(latitude: float, longitude: float, radius: int) -> list[dict[str, object]]:
    """Find mapped accommodation near a point through Geoapify Places."""
    if not GEOAPIFY_API_KEY:
        raise URLError("Geoapify is not configured. Add MEDIBRIDGE_GEOAPIFY_API_KEY to .env and restart MediBridge.")
    cache_key = f"geoapify-hotels:{latitude:.5f}:{longitude:.5f}:{radius}"

    def search():
        params = urlencode({
            "categories": "accommodation",
            "filter": f"circle:{longitude},{latitude},{radius}",
            "bias": f"proximity:{longitude},{latitude}",
            "limit": "20",
            "lang": "en",
            "apiKey": GEOAPIFY_API_KEY,
        })
        result = fetch_json(f"{GEOAPIFY_PLACES_URL}{params}", timeout=18)
        features = result.get("features", [])
        if not isinstance(features, list):
            return []
        hotels = []
        for feature in features:
            if not isinstance(feature, dict):
                continue
            properties = feature.get("properties") if isinstance(feature.get("properties"), dict) else {}
            geometry = feature.get("geometry") if isinstance(feature.get("geometry"), dict) else {}
            coordinates = geometry.get("coordinates") if isinstance(geometry.get("coordinates"), list) else []
            if len(coordinates) < 2:
                continue
            lon = number_value(coordinates[0], float("nan"))
            lat = number_value(coordinates[1], float("nan"))
            if not (math.isfinite(lat) and math.isfinite(lon) and -90 <= lat <= 90 and -180 <= lon <= 180):
                continue
            name = text_value(properties.get("name") or properties.get("address_line1"), 180)
            if not name:
                continue
            raw = properties.get("datasource") if isinstance(properties.get("datasource"), dict) else {}
            raw = raw.get("raw") if isinstance(raw.get("raw"), dict) else {}
            categories = properties.get("categories") if isinstance(properties.get("categories"), list) else []
            lodging_category = next((str(category) for category in categories if str(category).startswith("accommodation")), "accommodation")
            lodging_type = lodging_category.rsplit(".", 1)[-1].replace("_", " ").title()
            distance = number_value(properties.get("distance"), geo_distance_meters(latitude, longitude, lat, lon))
            place_id = text_value(properties.get("place_id"), 180)
            map_url = f"https://www.google.com/maps/search/?api=1&query={lat},{lon}"
            hotels.append({
                "id": f"geoapify:{place_id or uuid.uuid5(uuid.NAMESPACE_URL, name + str(lat) + str(lon))}",
                "displayName": {"text": name},
                "formattedAddress": text_value(properties.get("formatted") or properties.get("address_line2"), 300),
                "location": {"latitude": lat, "longitude": lon},
                "distanceMeters": max(0, distance),
                "rating": None, "userRatingCount": 0,
                "hotelClass": number_value(raw.get("stars"), 0) or None,
                "lodgingType": lodging_type,
                "photos": [],
                "websiteUri": text_value(raw.get("website") or raw.get("contact:website"), 300),
                "nationalPhoneNumber": text_value(raw.get("phone") or raw.get("contact:phone"), 60),
                "mapUrl": map_url,
                "source": "Geoapify",
            })
        return sorted(hotels, key=lambda hotel: hotel["distanceMeters"])[:10]

    return cache_value(cache_key, search, ttl_seconds=14400)


def geoapify_city_hotels(city: str, state: str, radius: int) -> tuple[list[dict[str, object]], str]:
    if not city.strip():
        return [], ""
    place = geoapify_city_location(city, state)
    if not place:
        raise ValueError(f"Geoapify could not locate {city}, {state}, India.")
    location = place["location"]
    listings = geoapify_nearby_hotels(float(location["latitude"]), float(location["longitude"]), radius)
    return listings, str(place["displayName"]["text"])


def geoapify_hospital_hotels(name: str, city: str, state: str, radius: int, address: str = "") -> tuple[list[dict[str, object]], str, str, str]:
    """Prefer a confident facility match, then use the selected city centre."""
    name, city, state = text_value(name, 180), text_value(city, 100), text_value(state, 100)
    if not name or not city:
        raise ValueError("Choose a hospital and city to find nearby stays.")
    notice = ""
    try:
        place = geoapify_hospital_location(name, city, state, address)
        if place:
            location = place["location"]
            listings = geoapify_nearby_hotels(float(location["latitude"]), float(location["longitude"]), radius)
            if listings:
                return listings, str(place["displayName"]["text"]), "hospital", ""
            notice = "No Geoapify stays were returned around this hospital; showing city-area results."
        else:
            notice = "No confident Geoapify match for this hospital; showing city-area results."
    except HTTPError as error:
        if error.code in {401, 403, 429}:
            raise
        notice = f"Hospital location lookup unavailable ({error}); showing city-area results."
    except (URLError, TimeoutError, ValueError) as error:
        notice = f"Hospital location lookup unavailable ({error}); showing city-area results."
    listings, origin = geoapify_city_hotels(city, state, radius)
    return listings, origin or city, "city-centre", notice


def hotel_provider_name() -> str:
    if GEOAPIFY_API_KEY:
        return "Geoapify"
    if MAPPLS_ACCESS_TOKEN:
        return "Mappls"
    return "OpenStreetMap"


def find_hospital_hotels(name: str, city: str, state: str, radius: int, address: str = "") -> tuple[list[dict[str, object]], str, str, str, str]:
    provider = hotel_provider_name()
    if provider == "Geoapify":
        data, origin, origin_type, notice = geoapify_hospital_hotels(name, city, state, radius, address)
    elif provider == "Mappls":
        data, origin, origin_type, notice = mappls_hospital_hotels(name, city, state, radius)
    else:
        data, origin, origin_type, notice = osm_hospital_hotels(name, city, state, radius)
    return data, origin, origin_type, notice, provider


def find_city_hotels(city: str, state: str, radius: int) -> tuple[list[dict[str, object]], str, str]:
    provider = hotel_provider_name()
    if provider == "Geoapify":
        data, origin = geoapify_city_hotels(city, state, radius)
    elif provider == "Mappls":
        data, origin = mappls_city_hotels(city, state, radius)
    else:
        data, origin = osm_city_hotels(city, state, radius)
    return data, origin, provider


def find_nearby_hotels(latitude: float, longitude: float, radius: int) -> tuple[list[dict[str, object]], str]:
    provider = hotel_provider_name()
    if provider == "Geoapify":
        data = geoapify_nearby_hotels(latitude, longitude, radius)
    elif provider == "Mappls":
        data = mappls_nearby_hotels(f"{latitude},{longitude}", radius)
    else:
        data = osm_nearby_hotels(latitude, longitude, radius)
    return data, provider


def osm_nearby_hotels(latitude: float, longitude: float, radius: int) -> list[dict[str, object]]:
    cache_key = f"overpass:hotels:{latitude:.4f}:{longitude:.4f}:{radius}"

    def search():
        query = f"""[out:json][timeout:10];
nwr(around:{radius},{latitude},{longitude})[\"tourism\"~\"^(hotel|guest_house|motel|hostel|apartment|resort)$\"];
out center qt 60;"""
        body = urlencode({"data": query}).encode("utf-8")
        endpoints = list(dict.fromkeys((OVERPASS_URL, OVERPASS_FALLBACK_URL, OVERPASS_TERTIARY_URL)))
        result = None
        last_error = None
        for endpoint in endpoints:
            try:
                result = fetch_json(endpoint, method="POST", body=body,
                                    headers={"Content-Type": "application/x-www-form-urlencoded"}, timeout=15)
                break
            except HTTPError as error:
                # Don't bypass a public endpoint's explicit rate limit or a bad query.
                if error.code not in {500, 502, 503, 504}:
                    raise
                last_error = error
            except (URLError, TimeoutError) as error:
                last_error = error
        if result is None:
            if last_error is not None:
                raise last_error
            raise URLError("No OpenStreetMap hotel data endpoint is configured.")
        elements = result.get("elements", [])
        hotels = []
        for element in elements:
            tags = element.get("tags") if isinstance(element.get("tags"), dict) else {}
            name = str(tags.get("name", "")).strip()
            if not name:
                continue
            center = element.get("center") if isinstance(element.get("center"), dict) else element
            lat, lon = number_value(center.get("lat"), float("nan")), number_value(center.get("lon"), float("nan"))
            if not (math.isfinite(lat) and math.isfinite(lon)):
                continue
            distance = geo_distance_meters(latitude, longitude, lat, lon)
            osm_type, osm_id = str(element.get("type", "")), str(element.get("id", ""))
            osm_url = f"https://www.openstreetmap.org/{osm_type}/{osm_id}"
            address = ", ".join(str(tags.get(key)) for key in ("addr:housenumber", "addr:street", "addr:suburb", "addr:city") if tags.get(key))
            commons = str(tags.get("wikimedia_commons", ""))
            city = str(tags.get("addr:city") or tags.get("addr:suburb") or "")
            photo = commons_photo(commons, name, city, "hotel") if commons else None
            hotels.append({
                "id": f"{osm_type}:{osm_id}", "displayName": {"text": name},
                "formattedAddress": address or f"{distance / 1000:.1f} km from selected hospital",
                "location": {"latitude": lat, "longitude": lon}, "distanceMeters": distance,
                "rating": None, "userRatingCount": 0,
                "hotelClass": number_value(tags.get("stars"), 0) or None,
                "lodgingType": str(tags.get("tourism", "hotel")).replace("_", " ").title(),
                "photos": [photo] if photo else [],
                "websiteUri": tags.get("website") or tags.get("contact:website") or "",
                "nationalPhoneNumber": tags.get("phone") or tags.get("contact:phone") or "",
                "osmUrl": osm_url, "source": "OpenStreetMap",
            })
        return sorted(hotels, key=lambda hotel: hotel["distanceMeters"])[:10]

    return cache_value(cache_key, search, ttl_seconds=14400)


def osm_city_hotels(city: str, state: str, radius: int) -> tuple[list[dict[str, object]], str]:
    """Use city-centre listings when no reliable hospital map pin is available."""
    query = ", ".join(part for part in (city, state, "India") if part)
    if not city.strip():
        return [], ""
    primary_error: BaseException | None = None
    try:
        places = osm_hospital_search(query)
    except HTTPError as error:
        if error.code < 500:
            raise
        primary_error = error
        places = []
    except (URLError, TimeoutError) as error:
        primary_error = error
        places = []
    city_place = next((place for place in places if place.get("location", {}).get("latitude") is not None), None)
    if not city_place:
        try:
            city_place = photon_city_location(city, state)
        except (HTTPError, URLError, TimeoutError, ValueError):
            if primary_error:
                raise primary_error
            raise
    if not city_place:
        return [], ""
    location = city_place["location"]
    listings = osm_nearby_hotels(float(location["latitude"]), float(location["longitude"]), radius)
    return listings, str(city_place.get("displayName", {}).get("text", city))


def osm_hospital_hotels(name: str, city: str, state: str, radius: int) -> tuple[list[dict[str, object]], str, str, str]:
    """Search near a confidently matched OSM hospital; otherwise use the city centre."""
    name = text_value(name, 180)
    city = text_value(city, 100)
    state = text_value(state, 100)
    query = ", ".join(part for part in (name, city, state, "India") if part)
    places = osm_hospital_search(query)
    ignored = {"hospital", "hospitals", "clinic", "medical", "center", "centre", "the", "and", "of", "in", "india"}
    tokens = [token for token in re.findall(r"[a-z0-9]+", name.casefold()) if len(token) > 2 and token not in ignored]
    matched = []
    for place in places:
        location = place.get("location", {})
        if not isinstance(location, dict):
            continue
        try:
            latitude = float(location.get("latitude"))
            longitude = float(location.get("longitude"))
        except (TypeError, ValueError):
            continue
        map_class = str(place.get("mapClass", "")).casefold()
        label = str(place.get("displayName", {}).get("text", ""))
        haystack = re.sub(r"[^a-z0-9]+", " ", f"{label} {place.get('formattedAddress', '')} {map_class}".casefold()).split()
        overlap = sum(token in haystack for token in tokens) / max(1, len(tokens))
        is_health_facility = any(word in map_class for word in ("hospital", "clinic", "healthcare"))
        if overlap >= 0.4 and is_health_facility:
            matched.append((overlap, place, latitude, longitude))
    if matched:
        _, place, latitude, longitude = max(matched, key=lambda item: item[0])
        origin = str(place.get("displayName", {}).get("text", name))
        listings = osm_nearby_hotels(latitude, longitude, radius)
        if listings:
            return listings, origin, "hospital", ""
        notice = "No nearby mapped stays around this hospital; showing city-centre results."
    else:
        notice = "No confident hospital map match; showing city-centre results."
    listings, origin = osm_city_hotels(city, state, radius)
    return listings, origin or city, "city-centre", notice


def connect_database() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def initialize_database() -> None:
    with closing(connect_database()) as connection:
        connection.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        connection.commit()


def text_value(value: object, limit: int, default: str = "") -> str:
    if value is None:
        return default
    return str(value).strip()[:limit]


def number_value(value: object, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number if math.isfinite(number) else default


def optional_number(value: object) -> float | None:
    if value is None or value == "":
        return None
    return number_value(value)


def read_state() -> dict[str, object]:
    with closing(connect_database()) as connection:
        saved = connection.execute(
            "SELECT preferences_json FROM app_state WHERE singleton_id = 1"
        ).fetchone()
        estimates = connection.execute(
            """SELECT id, treatment, total, mode, budget, currency,
                      visit_start_date, visit_end_date, created_at
               FROM trip_estimates ORDER BY position ASC"""
        ).fetchall()
        enquiries = connection.execute(
            """SELECT id, reference, patient_name, email, treatment_name,
                      hospital_name, hospital_id, visit_start_date,
                      visit_end_date, message, status, created_at
               FROM enquiries ORDER BY position ASC"""
        ).fetchall()

    preferences = json.loads(saved["preferences_json"]) if saved else {}
    return {
        "hasSavedState": bool(saved or estimates or enquiries),
        "preferences": preferences,
        "estimates": [
            {
                "id": row["id"],
                "treatment": row["treatment"],
                "total": row["total"],
                "mode": row["mode"],
                "budget": row["budget"],
                "currency": row["currency"],
                "visitStartDate": row["visit_start_date"],
                "visitEndDate": row["visit_end_date"],
                "createdAt": row["created_at"],
            }
            for row in estimates
        ],
        "enquiries": [
            {
                "id": row["id"],
                "reference": row["reference"],
                "patientName": row["patient_name"],
                "email": row["email"],
                "treatmentName": row["treatment_name"],
                "hospitalName": row["hospital_name"],
                "hospitalId": row["hospital_id"],
                "visitStartDate": row["visit_start_date"],
                "visitEndDate": row["visit_end_date"],
                "message": row["message"],
                "status": row["status"],
                "createdAt": row["created_at"],
            }
            for row in enquiries
        ],
    }


def save_state(payload: object) -> None:
    if not isinstance(payload, dict):
        raise ValueError("The request must contain a state object.")

    raw_estimates = payload.get("estimates", [])
    raw_enquiries = payload.get("enquiries", [])
    if not isinstance(raw_estimates, list) or not isinstance(raw_enquiries, list):
        raise ValueError("Estimates and enquiries must be lists.")

    raw_preferences = {
        key: value
        for key, value in payload.items()
        if key not in {"estimates", "enquiries"}
    }
    preferences_json = json.dumps(raw_preferences, ensure_ascii=False, allow_nan=False)
    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")

    with closing(connect_database()) as connection:
        connection.execute("BEGIN IMMEDIATE")
        connection.execute(
            """INSERT INTO app_state(singleton_id, preferences_json, updated_at)
               VALUES (1, ?, ?)
               ON CONFLICT(singleton_id) DO UPDATE SET
                   preferences_json = excluded.preferences_json,
                   updated_at = excluded.updated_at""",
            (preferences_json, timestamp),
        )

        connection.execute("DELETE FROM trip_estimates")
        for position, item in enumerate(raw_estimates[:1000]):
            if not isinstance(item, dict):
                continue
            mode = text_value(item.get("mode"), 16, "hospital")
            if mode not in ALLOWED_ESTIMATE_MODES:
                mode = "hospital"
            connection.execute(
                """INSERT INTO trip_estimates(
                       id, position, treatment, total, mode, budget, currency,
                       visit_start_date, visit_end_date, created_at
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    text_value(item.get("id"), 100, f"estimate-{position + 1}"),
                    position,
                    text_value(item.get("treatment"), 120, "Treatment estimate"),
                    number_value(item.get("total")),
                    mode,
                    optional_number(item.get("budget")),
                    text_value(item.get("currency"), 3, "USD").upper(),
                    text_value(item.get("visitStartDate"), 32),
                    text_value(item.get("visitEndDate"), 32),
                    text_value(item.get("createdAt"), 40),
                ),
            )

        connection.execute("DELETE FROM enquiries")
        for position, item in enumerate(raw_enquiries[:1000]):
            if not isinstance(item, dict):
                continue
            status = text_value(item.get("status"), 32, "Received")
            if status not in ALLOWED_ENQUIRY_STATUSES:
                status = "Received"
            connection.execute(
                """INSERT INTO enquiries(
                       id, position, reference, patient_name, email,
                       treatment_name, hospital_name, hospital_id,
                       visit_start_date, visit_end_date, message, status, created_at
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    text_value(item.get("id"), 100, f"enquiry-{uuid.uuid4().hex}"),
                    position,
                    text_value(item.get("reference"), 50, f"MB-{uuid.uuid4().hex[:8].upper()}"),
                    text_value(item.get("patientName"), 120),
                    text_value(item.get("email"), 254),
                    text_value(item.get("treatmentName"), 120),
                    text_value(item.get("hospitalName"), 160),
                    text_value(item.get("hospitalId"), 100),
                    text_value(item.get("visitStartDate"), 32),
                    text_value(item.get("visitEndDate"), 32),
                    text_value(item.get("message"), 500),
                    status,
                    text_value(item.get("createdAt"), 40),
                ),
            )
        connection.commit()


class MediBridgeHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args: object, **kwargs: object) -> None:
        super().__init__(*args, directory=str(APP_DIR), **kwargs)

    def send_json(self, payload: dict[str, object], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_image(self, body: bytes, content_type: str) -> None:
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=3600")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        # SimpleHTTPRequestHandler otherwise serves dotfiles on direct requests.
        if Path(unquote(path)).name == ".env":
            self.send_error(404)
            return
        params = parse_qs(parsed.query)
        value = lambda key, default="": params.get(key, [default])[0]
        if path == "/api/state":
            self.send_json(read_state())
        elif path == "/api/health":
            self.send_json({
                "ok": True,
                "database": "SQLite",
                "python": platform.python_version(),
                "tlsBackend": ssl.OPENSSL_VERSION,
                "livePlacesConfigured": True,
                "placeDataSource": "OpenStreetMap",
                "hotelDataSource": hotel_provider_name(),
                "geoapifyConfigured": bool(GEOAPIFY_API_KEY),
                "mapplsConfigured": bool(MAPPLS_ACCESS_TOKEN),
                "photoDataSource": "Wikimedia Commons name search with license metadata",
            })
        elif path == "/api/live/hospital":
            query = text_value(value("query"), 300)
            if not query:
                self.send_json({"error": "A hospital search query is required."}, status=400)
                return
            try:
                data = osm_hospital_search(query)
                self.send_json({"configured": True, "data": data, "checkedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"), "source": "OpenStreetMap"})
            except (HTTPError, URLError, TimeoutError, ValueError) as error:
                self.send_json({"configured": True, "error": f"OpenStreetMap hospital lookup failed: {live_provider_error(error)}"}, status=502)
        elif path == "/api/live/photo":
            name = text_value(value("name"), 180)
            city = text_value(value("city"), 100)
            place_type = text_value(value("type", "hospital"), 20)
            if not name or place_type not in {"hospital", "hotel"}:
                self.send_json({"error": "A place name and type (hospital or hotel) are required."}, status=400)
                return
            photo = commons_search_photo(name, city, place_type)
            self.send_json({"configured": True, "data": photo, "source": "Wikimedia Commons"})
        elif path == "/api/live/location":
            name = text_value(value("hospital"), 180)
            address = text_value(value("address"), 180)
            city = text_value(value("city"), 100)
            state = text_value(value("state"), 100)
            if not city:
                self.send_json({"error": "A city is required to locate the map."}, status=400)
                return
            try:
                location = (geoapify_hospital_location(name, city, state, address)
                            if name else geoapify_city_location(city, state))
                if not location:
                    self.send_json({"error": "No confident map location was found."}, status=404)
                    return
                self.send_json({"configured": True, "data": location, "source": "Geoapify Geocoding"})
            except (HTTPError, URLError, TimeoutError, ValueError) as error:
                self.send_json({"configured": bool(GEOAPIFY_API_KEY),
                                "error": f"Map location lookup failed: {live_provider_error(error)}"}, status=502)
        elif re.fullmatch(r"/api/map-tiles/\d+/\d+/\d+\.png", path):
            if not GEOAPIFY_API_KEY:
                self.send_json({"error": "Add a Geoapify key with Map Tiles enabled to display the interactive map."}, status=503)
                return
            match = re.fullmatch(r"/api/map-tiles/(\d+)/(\d+)/(\d+)\.png", path)
            assert match is not None
            zoom, tile_x, tile_y = map(int, match.groups())
            tile_limit = 1 << zoom if 0 <= zoom <= 20 else 0
            if not tile_limit or tile_x >= tile_limit or tile_y >= tile_limit:
                self.send_json({"error": "Invalid map tile coordinates."}, status=400)
                return
            tile_url = (f"https://maps.geoapify.com/v1/tile/positron/{zoom}/{tile_x}/{tile_y}.png?"
                        + urlencode({"apiKey": GEOAPIFY_API_KEY}))
            try:
                tile = cache_value(f"geoapify-tile:{zoom}:{tile_x}:{tile_y}",
                                   lambda: fetch_image(tile_url), ttl_seconds=3600)
                self.send_image(tile, "image/png")
            except (HTTPError, URLError, TimeoutError, ValueError) as error:
                self.send_json({"error": f"Map tiles are unavailable: {live_provider_error(error)}"}, status=502)
        elif path == "/api/live/nearby-hotels":
            try:
                latitude = number_value(value("latitude"), float("nan"))
                longitude = number_value(value("longitude"), float("nan"))
                radius = int(value("radius", "3000"))
                if not (math.isfinite(latitude) and math.isfinite(longitude) and -90 <= latitude <= 90 and -180 <= longitude <= 180):
                    raise ValueError("Valid latitude and longitude are required.")
                if not 500 <= radius <= 10000:
                    raise ValueError("Radius must be between 500 and 10000 metres.")
                data, source = find_nearby_hotels(latitude, longitude, radius)
                self.send_json({"configured": True, "data": data, "checkedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"), "source": source})
            except ValueError as error:
                self.send_json({"error": str(error)}, status=400)
            except (HTTPError, URLError, TimeoutError) as error:
                source = hotel_provider_name()
                self.send_json({"configured": True, "error": f"{source} hotel lookup failed: {live_provider_error(error)}"}, status=502)
        elif path == "/api/live/hospital-hotels":
            hospital_name = text_value(value("hospital"), 180)
            hospital_address = text_value(value("address"), 180)
            city = text_value(value("city"), 100)
            state = text_value(value("state"), 100)
            try:
                radius = int(value("radius", "5000"))
                if not hospital_name or not city:
                    raise ValueError("Choose a hospital and city to find nearby stays.")
                if not 1000 <= radius <= 10000:
                    raise ValueError("Radius must be between 1000 and 10000 metres.")
                data, origin, origin_type, notice, source = find_hospital_hotels(hospital_name, city, state, radius, hospital_address)
                self.send_json({"configured": True, "data": data, "origin": origin, "originType": origin_type,
                                "notice": notice, "checkedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                                "source": source})
            except ValueError as error:
                self.send_json({"error": str(error)}, status=400)
            except (HTTPError, URLError, TimeoutError) as error:
                source = hotel_provider_name()
                self.send_json({"configured": bool(GEOAPIFY_API_KEY or MAPPLS_ACCESS_TOKEN), "error": f"{source} hospital hotel lookup failed: {live_provider_error(error)}"}, status=502)
        elif path == "/api/live/city-hotels":
            city = text_value(value("city"), 100)
            state = text_value(value("state"), 100)
            try:
                radius = int(value("radius", "8000"))
                if not city:
                    raise ValueError("A city is required to find nearby stays.")
                if not 1000 <= radius <= 10000:
                    raise ValueError("Radius must be between 1000 and 10000 metres.")
                data, origin, source = find_city_hotels(city, state, radius)
                self.send_json({"configured": True, "data": data, "origin": origin, "checkedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"), "source": source})
            except ValueError as error:
                self.send_json({"error": str(error)}, status=400)
            except (HTTPError, URLError, TimeoutError) as error:
                source = hotel_provider_name()
                self.send_json({"configured": bool(GEOAPIFY_API_KEY or MAPPLS_ACCESS_TOKEN), "error": f"{source} city hotel lookup failed: {live_provider_error(error)}"}, status=502)
        else:
            super().do_GET()

    def do_PUT(self) -> None:
        if urlparse(self.path).path != "/api/state":
            self.send_json({"error": "Not found"}, status=404)
            return
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_json({"error": "Invalid content length"}, status=400)
            return
        if content_length <= 0 or content_length > MAX_BODY_BYTES:
            self.send_json({"error": "Request body is empty or too large"}, status=413)
            return
        try:
            payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
            save_state(payload)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
            self.send_json({"error": str(error)}, status=400)
            return
        except sqlite3.Error:
            self.send_json({"error": "Could not write to the local database"}, status=500)
            return
        self.send_json({"ok": True})


def main() -> None:
    initialize_database()
    server = ThreadingHTTPServer((HOST, PORT), MediBridgeHandler)
    print(f"MediBridge is running at http://{HOST}:{PORT}/")
    print(f"SQLite database: {DATABASE_PATH}")
    print("Keep this window open while using MediBridge. Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nMediBridge server stopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
