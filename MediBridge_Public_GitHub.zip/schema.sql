PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS app_state (
    singleton_id INTEGER PRIMARY KEY CHECK (singleton_id = 1),
    preferences_json TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS trip_estimates (
    id TEXT PRIMARY KEY,
    position INTEGER NOT NULL,
    treatment TEXT NOT NULL,
    total REAL NOT NULL,
    mode TEXT NOT NULL CHECK (mode IN ('hospital', 'overall')),
    budget REAL,
    currency TEXT NOT NULL,
    visit_start_date TEXT NOT NULL DEFAULT '',
    visit_end_date TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS enquiries (
    id TEXT PRIMARY KEY,
    position INTEGER NOT NULL,
    reference TEXT NOT NULL UNIQUE,
    patient_name TEXT NOT NULL,
    email TEXT NOT NULL,
    treatment_name TEXT NOT NULL,
    hospital_name TEXT NOT NULL,
    hospital_id TEXT NOT NULL,
    visit_start_date TEXT NOT NULL DEFAULT '',
    visit_end_date TEXT NOT NULL DEFAULT '',
    message TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL CHECK (status IN ('Received', 'Under review', 'Quotation ready', 'Closed')),
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS trip_estimates_position_idx
    ON trip_estimates(position);
CREATE INDEX IF NOT EXISTS enquiries_position_idx
    ON enquiries(position);
