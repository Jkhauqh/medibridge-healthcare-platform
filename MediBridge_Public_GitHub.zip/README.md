# MediBridge local database

The prototype uses SQLite for local persistence. Python's built-in `sqlite3` module creates the database automatically the first time the server starts; no database account, paid service, or extra Python package is required.

## Start the database-backed prototype

1. Open a terminal in this folder and run `python3 server.py`.
2. Open <http://127.0.0.1:8765/> in your browser.
3. Keep the Terminal window open while using the prototype.
4. On the sign-in screen, enter `admin@example.com` to open the Admin workspace. Any other valid email address opens the Patient workspace.

Patients can use the trip planner, hospital search and comparison, and itinerary. They can submit quotation requests and track the status of requests linked to their entered email. Only the Admin workspace shows the complete patient enquiry inbox and actions to approve requests or mark quotations ready. Marking a quotation ready updates the patient's tracker; this prototype does not send an email or a real quotation document.

The admin-only analytics page summarizes patient sign-ins, patient page views, enquiry statuses, and saved estimates. Sign-in and page-view events are stored as aggregate activity without patient email addresses. The seven-day traffic chart starts collecting data after this feature is opened in the app; it does not import past browser visits.

Role routing and patient email filtering are front-end demonstrations only. The app checks the typed email in the browser; it does not sign in to Google, verify email ownership, or provide production access control. The local database is shared on this device. Do not use it for real accounts or patient information.

Opening `index.html` directly with a `file://` URL continues to use browser storage. To use SQLite, open the `http://127.0.0.1:8765/` address served by the local server.

## Database location and tables

The SQLite file is created at `data/medibridge.sqlite3` in this folder. The table definitions are in `schema.sql`. The database contains:

- `app_state` — trip-planning preferences, current selections, and aggregate patient activity events.
- `trip_estimates` — saved treatment and trip estimates.
- `enquiries` — local quotation enquiry records and their demo statuses.

The local server listens only on this computer (`127.0.0.1`). This academic prototype has no Google OAuth, verified user accounts, production authorization, encryption, provider messaging, or multi-user access controls. A production login needs Google OAuth with server-side ID-token verification and admin authorization. Do not enter real passwords, medical records, or sensitive patient details.

Press `Control+C` in the server's Terminal window to stop it. The database remains on this device.

## Hospital directory and nearby hotels

The hospital directory contains 280 records across India's 28 states from the National Hospital Directory dataset on [data.gov.in](https://www.data.gov.in/resource/national-hospital-directory-geo-code-and-additional-parameters-updated-till-last-month). This is a dated public-data snapshot, not a live hospital feed. It does not confirm that a facility is open, currently empanelled, offers a particular treatment, has appointments, or has a current treatment quote.

The **Find hotels** tab uses Geoapify Geocoding and Places APIs to search for accommodation around a selected hospital or city. Create a free project at [Geoapify MyProjects](https://myprojects.geoapify.com/), copy its API key, and set `MEDIBRIDGE_GEOAPIFY_API_KEY` in the local `.env` file. Restart `Start_MediBridge.command` after saving the key. The key is read by the Python server and is not included in the webpage. Geoapify is used when its key is configured; otherwise MediBridge uses Mappls when its key is configured, then the OpenStreetMap lookup fallback. The Geoapify results are based on OpenStreetMap place data, may be incomplete, and do not verify hotel availability. Keep the Geoapify and OpenStreetMap attribution displayed in the Find hotels section. Free-tier quotas and provider terms apply.

The app searches Wikimedia Commons for licensed photos of hospitals and nearby stays. It now requires a distinctive place-name match and facility-related context in the file title before displaying an image, including images linked from map records. This conservative filter can show a placeholder where no sufficiently clear match is found. A match is still not proof that a photo depicts the exact facility; check its Commons page and credit link. The directory and map data do not provide customer reviews or ratings, so the app does not invent them.

Geoapify and Mappls provide place locations, not room prices or booking availability. OYO's room prices change with dates and availability. No public OYO hotel-rate API was found in the official material, so this academic app does not scrape its consumer website. Each stay card links to a date-and-city rate search and lets the patient enter the current nightly amount they see. The trip estimate then uses that entered price multiplied by the planned nights; when no price is entered, the app uses its clearly labelled planning tier allowance (₹1,500, ₹3,000 or ₹6,000 per night). Confirm final price, taxes, room availability and cancellation terms with the booking provider before making plans. Photos are possible matches from licensed Wikimedia Commons files when available. Treatment costs, flights, transport and country-based other expenses are illustrative estimates. The currency conversion uses the app's reference-rate feed when online.

The server uses normal certificate verification for every provider request. If Python rejects a certificate chain on macOS, it retries through the system `curl` SecureTransport backend, which uses macOS Keychain trust; it never disables TLS verification. If that retry also fails with a self-signed certificate, the current network may be intercepting HTTPS with a root certificate that macOS does not trust. Try another network or have its administrator confirm and install the official trusted root certificate. The `/api/health` endpoint reports the active Python and TLS library.

Use the local server URL (`http://127.0.0.1:8765/`), not a `file://` URL. Geoapify access requires the configured API key; the server reports the active hotel-location provider at `/api/health`. Wikimedia Commons photo lookups may be unavailable or have incomplete coverage. Prices are planning estimates and are not a booking or treatment quote.


## Public repository safety

This repository intentionally excludes the local SQLite database, patient enquiry records, local `.env` files, and personal API credentials. To enable optional hotel search, create your own provider key and store it locally in `.env` as `MEDIBRIDGE_GEOAPIFY_API_KEY=your_key_here` or `MEDIBRIDGE_MAPPLS_ACCESS_TOKEN=your_token_here`. Never commit `.env` or real credentials. The app uses `admin@example.com` as a public demo admin address; change it locally if needed.
